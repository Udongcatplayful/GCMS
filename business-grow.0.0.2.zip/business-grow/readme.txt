=== Business Grow ===

Contributors: Ample Themes
Requires at least: 4.5
Tested up to: 4.9.4
Stable tag: 1.0.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Business Grow is child theme of Ample Business.  Business Grow is a clean, simple and professional business theme with attractive elements and ample of features for business and corporate websites. It is well suited theme for business, corporate, informative, agencies, travel, design, art, personal ,woocommerce shop  and any other creative websites and blogs. It features multiple sections on the front page including favicon, logo, widgets, multiple navigations, address bar, social menus, and customizer to customize theme easily.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.


== Credits ==

== License ==

Business Grow WordPress Theme is child theme of Ample Business WordPress Theme, Copyright (C) 2017, Ample Themes
Business Grow  is distributed under the terms of the GNU GPL


Ample Business  WordPress Theme, Copyright (C) 2017, Ample Themes
Ample Business is distributed under the terms of the GNU GPL



============== Changelog =================
===2019/1/14-V-0.0.1===
* initial version

==2019/1/20==0.0.2===
* images changes in screenshot





== Images ==
Images used in screenshot are used from pixels

- Pexels images
License: https://www.pexels.com/photo-license/ (http://creativecommons.org/publicdomain/zero/1.0 - CC0)
https://www.pexels.com/photo/achievement-apple-computer-connection-414974/